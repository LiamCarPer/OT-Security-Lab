// Minimal debug table (debugger metadata only). The PLC logic and the
// located-variable / Modbus binding do not depend on it.
#include "generated.hpp"
#include "debug_table.hpp"

namespace strucpp { namespace debug {
const Entry* const debug_arrays[1] = { nullptr };
const uint16_t debug_array_counts[1] = { 0 };
const uint8_t debug_array_count = 0;
const RetainVar retain_vars[1] = { {0, 0} };
const uint16_t retain_var_count = 0;
const uint32_t retain_layout_hash = 0;
}}  // namespace strucpp::debug
